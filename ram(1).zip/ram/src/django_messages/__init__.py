VERSION = (0, 5, 1,)
__version__ = '.'.join(map(str, VERSION))
default_app_config = 'django_messages.apps.DjangoMessagesConfig'