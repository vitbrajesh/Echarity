  $("#header").load("header.html"); 
  $("#footer").load("footer.html"); 