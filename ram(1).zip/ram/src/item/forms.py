from django import forms

from .models import Donatable_item

class Donatable_itemForm(forms.ModelForm):

    class Meta:
        model = Post
        fields = ('title', 'text',)
