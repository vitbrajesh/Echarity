from django.contrib import admin
from .models import Donatable_item

admin.site.register(Donatable_item)
