from django.contrib import admin
from .models import List_items1

admin.site.register(List_items1)
